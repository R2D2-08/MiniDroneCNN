#ifndef __c1_flightControlSystem_h__
#define __c1_flightControlSystem_h__

/* Forward Declarations */
#ifndef c1_typedef_c1_sOxfNB8z9CRlM4WMwe0mNsC
#define c1_typedef_c1_sOxfNB8z9CRlM4WMwe0mNsC

typedef struct c1_tag_sOxfNB8z9CRlM4WMwe0mNsC c1_sOxfNB8z9CRlM4WMwe0mNsC;

#endif                                 /* c1_typedef_c1_sOxfNB8z9CRlM4WMwe0mNsC */

#ifndef c1_typedef_c1_cell_1
#define c1_typedef_c1_cell_1

typedef struct c1_tag_lfyg79q6Kpk0jaJgYJuk8C c1_cell_1;

#endif                                 /* c1_typedef_c1_cell_1 */

#ifndef c1_typedef_c1_cell_wrap_2
#define c1_typedef_c1_cell_wrap_2

typedef struct c1_tag_uwJsGEKtvfiUxcdf0z0AYH c1_cell_wrap_2;

#endif                                 /* c1_typedef_c1_cell_wrap_2 */

#ifndef c1_typedef_c1_cell_3
#define c1_typedef_c1_cell_3

typedef struct c1_tag_2iiteIdGaLsc8TaYxgpJoD c1_cell_3;

#endif                                 /* c1_typedef_c1_cell_3 */

#ifndef c1_typedef_c1_cell_4
#define c1_typedef_c1_cell_4

typedef struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE c1_cell_4;

#endif                                 /* c1_typedef_c1_cell_4 */

#ifndef c1_typedef_c1_cell_5
#define c1_typedef_c1_cell_5

typedef struct c1_tag_WYClaNMLzsYbJFiV2mng6F c1_cell_5;

#endif                                 /* c1_typedef_c1_cell_5 */

#ifndef c1_typedef_c1_cell_wrap_6
#define c1_typedef_c1_cell_wrap_6

typedef struct c1_tag_y2anywF90yUI9j7qH5yd3E c1_cell_wrap_6;

#endif                                 /* c1_typedef_c1_cell_wrap_6 */

#ifndef c1_typedef_c1_cell_7
#define c1_typedef_c1_cell_7

typedef struct c1_tag_6CsBRVljdCQyAxGT7eZM3E c1_cell_7;

#endif                                 /* c1_typedef_c1_cell_7 */

#ifndef c1_typedef_c1_cell_wrap_8
#define c1_typedef_c1_cell_wrap_8

typedef struct c1_tag_L5JvjW1A13FyCQi5N783sB c1_cell_wrap_8;

#endif                                 /* c1_typedef_c1_cell_wrap_8 */

#ifndef c1_typedef_c1_cell_9
#define c1_typedef_c1_cell_9

typedef struct c1_tag_TG9p2ZGDXoo1VFOxFDiXG c1_cell_9;

#endif                                 /* c1_typedef_c1_cell_9 */

#ifndef c1_typedef_c1_s_WSTEAPgNJmllMDXoFTifcF
#define c1_typedef_c1_s_WSTEAPgNJmllMDXoFTifcF

typedef struct c1_tag_WSTEAPgNJmllMDXoFTifcF c1_s_WSTEAPgNJmllMDXoFTifcF;

#endif                                 /* c1_typedef_c1_s_WSTEAPgNJmllMDXoFTifcF */

#ifndef c1_typedef_c1_s_MY3jsqmREaTzOC09vCGedD
#define c1_typedef_c1_s_MY3jsqmREaTzOC09vCGedD

typedef struct c1_tag_MY3jsqmREaTzOC09vCGedD c1_s_MY3jsqmREaTzOC09vCGedD;

#endif                                 /* c1_typedef_c1_s_MY3jsqmREaTzOC09vCGedD */

#ifndef c1_typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF
#define c1_typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF

typedef struct c1_tag_JWFNkfRUnt2nHgJh2qlbgF c1_s_JWFNkfRUnt2nHgJh2qlbgF;

#endif                                 /* c1_typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF */

#ifndef c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF
#define c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF

typedef struct c1_tag_ynaaIE6q9xznGBkza31TCF c1_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF */

#ifndef c1_typedef_c1_s_HSHOljOSgF7qDZeWd2IfH
#define c1_typedef_c1_s_HSHOljOSgF7qDZeWd2IfH

typedef struct c1_tag_HSHOljOSgF7qDZeWd2IfH c1_s_HSHOljOSgF7qDZeWd2IfH;

#endif                                 /* c1_typedef_c1_s_HSHOljOSgF7qDZeWd2IfH */

#ifndef c1_typedef_c1_s_BrRdqYMft44ulwR1A7rKqF
#define c1_typedef_c1_s_BrRdqYMft44ulwR1A7rKqF

typedef struct c1_tag_BrRdqYMft44ulwR1A7rKqF c1_s_BrRdqYMft44ulwR1A7rKqF;

#endif                                 /* c1_typedef_c1_s_BrRdqYMft44ulwR1A7rKqF */

#ifndef c1_typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH
#define c1_typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH

typedef struct c1_tag_i3ZGqykvgqQLsMCH6x4OBH c1_s_i3ZGqykvgqQLsMCH6x4OBH;

#endif                                 /* c1_typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD
#define c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD

typedef struct c1_tag_HOps0FrfA6RiWumqewPwZD c1_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD */

#ifndef c1_typedef_c1_s_xIv9xh4Qt5javKSREWQnWE
#define c1_typedef_c1_s_xIv9xh4Qt5javKSREWQnWE

typedef struct c1_tag_xIv9xh4Qt5javKSREWQnWE c1_s_xIv9xh4Qt5javKSREWQnWE;

#endif                                 /* c1_typedef_c1_s_xIv9xh4Qt5javKSREWQnWE */

/* Type Definitions */
#ifndef c1_struct_c1_tag_sOxfNB8z9CRlM4WMwe0mNsC
#define c1_struct_c1_tag_sOxfNB8z9CRlM4WMwe0mNsC

struct c1_tag_sOxfNB8z9CRlM4WMwe0mNsC
{
  char_T method[6];
};

#endif                                 /* c1_struct_c1_tag_sOxfNB8z9CRlM4WMwe0mNsC */

#ifndef c1_typedef_c1_sOxfNB8z9CRlM4WMwe0mNsC
#define c1_typedef_c1_sOxfNB8z9CRlM4WMwe0mNsC

typedef struct c1_tag_sOxfNB8z9CRlM4WMwe0mNsC c1_sOxfNB8z9CRlM4WMwe0mNsC;

#endif                                 /* c1_typedef_c1_sOxfNB8z9CRlM4WMwe0mNsC */

#ifndef c1_struct_c1_tag_lfyg79q6Kpk0jaJgYJuk8C
#define c1_struct_c1_tag_lfyg79q6Kpk0jaJgYJuk8C

struct c1_tag_lfyg79q6Kpk0jaJgYJuk8C
{
  char_T f1[5];
  char_T f2[6];
  char_T f3[6];
  char_T f4[6];
};

#endif                                 /* c1_struct_c1_tag_lfyg79q6Kpk0jaJgYJuk8C */

#ifndef c1_typedef_c1_cell_1
#define c1_typedef_c1_cell_1

typedef struct c1_tag_lfyg79q6Kpk0jaJgYJuk8C c1_cell_1;

#endif                                 /* c1_typedef_c1_cell_1 */

#ifndef c1_struct_c1_tag_uwJsGEKtvfiUxcdf0z0AYH
#define c1_struct_c1_tag_uwJsGEKtvfiUxcdf0z0AYH

struct c1_tag_uwJsGEKtvfiUxcdf0z0AYH
{
  char_T f1[4];
};

#endif                                 /* c1_struct_c1_tag_uwJsGEKtvfiUxcdf0z0AYH */

#ifndef c1_typedef_c1_cell_wrap_2
#define c1_typedef_c1_cell_wrap_2

typedef struct c1_tag_uwJsGEKtvfiUxcdf0z0AYH c1_cell_wrap_2;

#endif                                 /* c1_typedef_c1_cell_wrap_2 */

#ifndef c1_struct_c1_tag_2iiteIdGaLsc8TaYxgpJoD
#define c1_struct_c1_tag_2iiteIdGaLsc8TaYxgpJoD

struct c1_tag_2iiteIdGaLsc8TaYxgpJoD
{
  char_T f1[5];
  char_T f2[6];
  char_T f3[6];
  char_T f4[4];
  char_T f5[5];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
};

#endif                                 /* c1_struct_c1_tag_2iiteIdGaLsc8TaYxgpJoD */

#ifndef c1_typedef_c1_cell_3
#define c1_typedef_c1_cell_3

typedef struct c1_tag_2iiteIdGaLsc8TaYxgpJoD c1_cell_3;

#endif                                 /* c1_typedef_c1_cell_3 */

#ifndef c1_struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE
#define c1_struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE

struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE
{
  char_T f1[4];
  char_T f2[9];
  char_T f3[2];
};

#endif                                 /* c1_struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE */

#ifndef c1_typedef_c1_cell_4
#define c1_typedef_c1_cell_4

typedef struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE c1_cell_4;

#endif                                 /* c1_typedef_c1_cell_4 */

#ifndef c1_struct_c1_tag_WYClaNMLzsYbJFiV2mng6F
#define c1_struct_c1_tag_WYClaNMLzsYbJFiV2mng6F

struct c1_tag_WYClaNMLzsYbJFiV2mng6F
{
  char_T f1[6];
  char_T f2[5];
  char_T f3[4];
  char_T f4[7];
  char_T f5[6];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
  char_T f9[5];
};

#endif                                 /* c1_struct_c1_tag_WYClaNMLzsYbJFiV2mng6F */

#ifndef c1_typedef_c1_cell_5
#define c1_typedef_c1_cell_5

typedef struct c1_tag_WYClaNMLzsYbJFiV2mng6F c1_cell_5;

#endif                                 /* c1_typedef_c1_cell_5 */

#ifndef c1_struct_c1_tag_y2anywF90yUI9j7qH5yd3E
#define c1_struct_c1_tag_y2anywF90yUI9j7qH5yd3E

struct c1_tag_y2anywF90yUI9j7qH5yd3E
{
  char_T f1[9];
};

#endif                                 /* c1_struct_c1_tag_y2anywF90yUI9j7qH5yd3E */

#ifndef c1_typedef_c1_cell_wrap_6
#define c1_typedef_c1_cell_wrap_6

typedef struct c1_tag_y2anywF90yUI9j7qH5yd3E c1_cell_wrap_6;

#endif                                 /* c1_typedef_c1_cell_wrap_6 */

#ifndef c1_struct_c1_tag_6CsBRVljdCQyAxGT7eZM3E
#define c1_struct_c1_tag_6CsBRVljdCQyAxGT7eZM3E

struct c1_tag_6CsBRVljdCQyAxGT7eZM3E
{
  char_T f1[7];
  char_T f2[7];
  char_T f3[5];
  char_T f4[6];
  char_T f5[7];
  char_T f6[8];
};

#endif                                 /* c1_struct_c1_tag_6CsBRVljdCQyAxGT7eZM3E */

#ifndef c1_typedef_c1_cell_7
#define c1_typedef_c1_cell_7

typedef struct c1_tag_6CsBRVljdCQyAxGT7eZM3E c1_cell_7;

#endif                                 /* c1_typedef_c1_cell_7 */

#ifndef c1_struct_c1_tag_L5JvjW1A13FyCQi5N783sB
#define c1_struct_c1_tag_L5JvjW1A13FyCQi5N783sB

struct c1_tag_L5JvjW1A13FyCQi5N783sB
{
  char_T f1[7];
};

#endif                                 /* c1_struct_c1_tag_L5JvjW1A13FyCQi5N783sB */

#ifndef c1_typedef_c1_cell_wrap_8
#define c1_typedef_c1_cell_wrap_8

typedef struct c1_tag_L5JvjW1A13FyCQi5N783sB c1_cell_wrap_8;

#endif                                 /* c1_typedef_c1_cell_wrap_8 */

#ifndef c1_struct_c1_tag_TG9p2ZGDXoo1VFOxFDiXG
#define c1_struct_c1_tag_TG9p2ZGDXoo1VFOxFDiXG

struct c1_tag_TG9p2ZGDXoo1VFOxFDiXG
{
  char_T f1[6];
  char_T f2[4];
  char_T f3[6];
  char_T f4[9];
  char_T f5[11];
};

#endif                                 /* c1_struct_c1_tag_TG9p2ZGDXoo1VFOxFDiXG */

#ifndef c1_typedef_c1_cell_9
#define c1_typedef_c1_cell_9

typedef struct c1_tag_TG9p2ZGDXoo1VFOxFDiXG c1_cell_9;

#endif                                 /* c1_typedef_c1_cell_9 */

#ifndef c1_struct_c1_tag_WSTEAPgNJmllMDXoFTifcF
#define c1_struct_c1_tag_WSTEAPgNJmllMDXoFTifcF

struct c1_tag_WSTEAPgNJmllMDXoFTifcF
{
  c1_cell_1 _data;
};

#endif                                 /* c1_struct_c1_tag_WSTEAPgNJmllMDXoFTifcF */

#ifndef c1_typedef_c1_s_WSTEAPgNJmllMDXoFTifcF
#define c1_typedef_c1_s_WSTEAPgNJmllMDXoFTifcF

typedef struct c1_tag_WSTEAPgNJmllMDXoFTifcF c1_s_WSTEAPgNJmllMDXoFTifcF;

#endif                                 /* c1_typedef_c1_s_WSTEAPgNJmllMDXoFTifcF */

#ifndef c1_struct_c1_tag_MY3jsqmREaTzOC09vCGedD
#define c1_struct_c1_tag_MY3jsqmREaTzOC09vCGedD

struct c1_tag_MY3jsqmREaTzOC09vCGedD
{
  c1_cell_wrap_2 _data;
};

#endif                                 /* c1_struct_c1_tag_MY3jsqmREaTzOC09vCGedD */

#ifndef c1_typedef_c1_s_MY3jsqmREaTzOC09vCGedD
#define c1_typedef_c1_s_MY3jsqmREaTzOC09vCGedD

typedef struct c1_tag_MY3jsqmREaTzOC09vCGedD c1_s_MY3jsqmREaTzOC09vCGedD;

#endif                                 /* c1_typedef_c1_s_MY3jsqmREaTzOC09vCGedD */

#ifndef c1_struct_c1_tag_JWFNkfRUnt2nHgJh2qlbgF
#define c1_struct_c1_tag_JWFNkfRUnt2nHgJh2qlbgF

struct c1_tag_JWFNkfRUnt2nHgJh2qlbgF
{
  c1_cell_3 _data;
};

#endif                                 /* c1_struct_c1_tag_JWFNkfRUnt2nHgJh2qlbgF */

#ifndef c1_typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF
#define c1_typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF

typedef struct c1_tag_JWFNkfRUnt2nHgJh2qlbgF c1_s_JWFNkfRUnt2nHgJh2qlbgF;

#endif                                 /* c1_typedef_c1_s_JWFNkfRUnt2nHgJh2qlbgF */

#ifndef c1_struct_c1_tag_ynaaIE6q9xznGBkza31TCF
#define c1_struct_c1_tag_ynaaIE6q9xznGBkza31TCF

struct c1_tag_ynaaIE6q9xznGBkza31TCF
{
  c1_cell_4 _data;
};

#endif                                 /* c1_struct_c1_tag_ynaaIE6q9xznGBkza31TCF */

#ifndef c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF
#define c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF

typedef struct c1_tag_ynaaIE6q9xznGBkza31TCF c1_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* c1_typedef_c1_s_ynaaIE6q9xznGBkza31TCF */

#ifndef c1_struct_c1_tag_HSHOljOSgF7qDZeWd2IfH
#define c1_struct_c1_tag_HSHOljOSgF7qDZeWd2IfH

struct c1_tag_HSHOljOSgF7qDZeWd2IfH
{
  c1_cell_5 _data;
};

#endif                                 /* c1_struct_c1_tag_HSHOljOSgF7qDZeWd2IfH */

#ifndef c1_typedef_c1_s_HSHOljOSgF7qDZeWd2IfH
#define c1_typedef_c1_s_HSHOljOSgF7qDZeWd2IfH

typedef struct c1_tag_HSHOljOSgF7qDZeWd2IfH c1_s_HSHOljOSgF7qDZeWd2IfH;

#endif                                 /* c1_typedef_c1_s_HSHOljOSgF7qDZeWd2IfH */

#ifndef c1_struct_c1_tag_BrRdqYMft44ulwR1A7rKqF
#define c1_struct_c1_tag_BrRdqYMft44ulwR1A7rKqF

struct c1_tag_BrRdqYMft44ulwR1A7rKqF
{
  c1_cell_wrap_6 _data;
};

#endif                                 /* c1_struct_c1_tag_BrRdqYMft44ulwR1A7rKqF */

#ifndef c1_typedef_c1_s_BrRdqYMft44ulwR1A7rKqF
#define c1_typedef_c1_s_BrRdqYMft44ulwR1A7rKqF

typedef struct c1_tag_BrRdqYMft44ulwR1A7rKqF c1_s_BrRdqYMft44ulwR1A7rKqF;

#endif                                 /* c1_typedef_c1_s_BrRdqYMft44ulwR1A7rKqF */

#ifndef c1_struct_c1_tag_i3ZGqykvgqQLsMCH6x4OBH
#define c1_struct_c1_tag_i3ZGqykvgqQLsMCH6x4OBH

struct c1_tag_i3ZGqykvgqQLsMCH6x4OBH
{
  c1_cell_7 _data;
};

#endif                                 /* c1_struct_c1_tag_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef c1_typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH
#define c1_typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH

typedef struct c1_tag_i3ZGqykvgqQLsMCH6x4OBH c1_s_i3ZGqykvgqQLsMCH6x4OBH;

#endif                                 /* c1_typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef c1_struct_c1_tag_HOps0FrfA6RiWumqewPwZD
#define c1_struct_c1_tag_HOps0FrfA6RiWumqewPwZD

struct c1_tag_HOps0FrfA6RiWumqewPwZD
{
  c1_cell_wrap_8 _data;
};

#endif                                 /* c1_struct_c1_tag_HOps0FrfA6RiWumqewPwZD */

#ifndef c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD
#define c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD

typedef struct c1_tag_HOps0FrfA6RiWumqewPwZD c1_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* c1_typedef_c1_s_HOps0FrfA6RiWumqewPwZD */

#ifndef c1_struct_c1_tag_xIv9xh4Qt5javKSREWQnWE
#define c1_struct_c1_tag_xIv9xh4Qt5javKSREWQnWE

struct c1_tag_xIv9xh4Qt5javKSREWQnWE
{
  c1_cell_9 _data;
};

#endif                                 /* c1_struct_c1_tag_xIv9xh4Qt5javKSREWQnWE */

#ifndef c1_typedef_c1_s_xIv9xh4Qt5javKSREWQnWE
#define c1_typedef_c1_s_xIv9xh4Qt5javKSREWQnWE

typedef struct c1_tag_xIv9xh4Qt5javKSREWQnWE c1_s_xIv9xh4Qt5javKSREWQnWE;

#endif                                 /* c1_typedef_c1_s_xIv9xh4Qt5javKSREWQnWE */

#ifndef typedef_SFc1_flightControlSystemInstanceStruct
#define typedef_SFc1_flightControlSystemInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  int32_T c1_sfEvent;
  boolean_T c1_doneDoubleBufferReInit;
  void *c1_RuntimeVar;
  int32_T c1_IsDebuggerActive;
  int32_T c1_IsSequenceViewerPresent;
  int32_T c1_SequenceViewerOptimization;
  int32_T c1_IsHeatMapPresent;
  uint8_T c1_JITStateAnimation[1];
  uint8_T c1_JITTransitionAnimation[1];
  uint32_T c1_mlFcnLineNumber;
  void *c1_fcnDataPtrs[6];
  const char_T *c1_dataNames[6];
  uint32_T c1_numFcnVars;
  uint32_T c1_ssIds[6];
  uint32_T c1_statuses[6];
  void *c1_outMexFcns[6];
  void *c1_inMexFcns[6];
  CovrtStateflowInstance *c1_covrtInstance;
  void *c1_fEmlrtCtx;
  uint8_T (*c1_R)[19200];
  boolean_T (*c1_bwImage)[19200];
  uint8_T (*c1_G)[19200];
  uint8_T (*c1_B)[19200];
} SFc1_flightControlSystemInstanceStruct;

#endif                                 /* typedef_SFc1_flightControlSystemInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_flightControlSystem_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c1_flightControlSystem_get_check_sum(mxArray *plhs[]);
extern void c1_flightControlSystem_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
