/* Include files */

#include "flightControlSystem_sfun.h"
#include "c1_flightControlSystem.h"
#include "mwmathutil.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Forward Declarations */

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static emlrtMCInfo c1_emlrtMCI = { 14, /* lineNo */
  37,                                  /* colNo */
  "validatefinite",                    /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validatefinite.m"/* pName */
};

static emlrtMCInfo c1_b_emlrtMCI = { 14,/* lineNo */
  37,                                  /* colNo */
  "validatenonnegative",               /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validatenonnegative.m"/* pName */
};

static emlrtMCInfo c1_c_emlrtMCI = { 82,/* lineNo */
  5,                                   /* colNo */
  "power",                             /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\eml\\lib\\matlab\\ops\\power.m"/* pName */
};

static emlrtRSInfo c1_emlrtRSI = { 6,  /* lineNo */
  "Image Processing System/MATLAB Function",/* fcnName */
  "#flightControlSystem:2682"          /* pathName */
};

static emlrtRSInfo c1_b_emlrtRSI = { 9,/* lineNo */
  "Image Processing System/MATLAB Function",/* fcnName */
  "#flightControlSystem:2682"          /* pathName */
};

static emlrtRSInfo c1_c_emlrtRSI = { 49,/* lineNo */
  "rgb2gray",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\eml\\lib\\matlab\\images\\rgb2gray.m"/* pathName */
};

static emlrtRSInfo c1_d_emlrtRSI = { 70,/* lineNo */
  "imbinarize",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imbinarize.m"/* pathName */
};

static emlrtRSInfo c1_e_emlrtRSI = { 104,/* lineNo */
  "imbinarize",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imbinarize.m"/* pathName */
};

static emlrtRSInfo c1_f_emlrtRSI = { 133,/* lineNo */
  "imhist",                            /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m"/* pathName */
};

static emlrtRSInfo c1_g_emlrtRSI = { 170,/* lineNo */
  "imhist",                            /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m"/* pathName */
};

static emlrtRSInfo c1_h_emlrtRSI = { 207,/* lineNo */
  "imhist",                            /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m"/* pathName */
};

static emlrtRSInfo c1_i_emlrtRSI = { 452,/* lineNo */
  "imhist",                            /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m"/* pathName */
};

static emlrtRSInfo c1_j_emlrtRSI = { 14,/* lineNo */
  "warning",                           /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\shared\\coder\\coder\\lib\\+coder\\+internal\\warning.m"/* pathName */
};

static emlrtRSInfo c1_k_emlrtRSI = { 37,/* lineNo */
  "otsuthresh",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m"/* pathName */
};

static emlrtRSInfo c1_l_emlrtRSI = { 85,/* lineNo */
  "otsuthresh",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m"/* pathName */
};

static emlrtRSInfo c1_m_emlrtRSI = { 93,/* lineNo */
  "validateattributes",                /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\eml\\lib\\matlab\\lang\\validateattributes.m"/* pathName */
};

static emlrtRSInfo c1_n_emlrtRSI = { 44,/* lineNo */
  "mpower",                            /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\eml\\lib\\matlab\\matfun\\mpower.m"/* pathName */
};

static emlrtRSInfo c1_o_emlrtRSI = { 71,/* lineNo */
  "power",                             /* fcnName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\eml\\lib\\matlab\\ops\\power.m"/* pathName */
};

static emlrtBCInfo c1_emlrtBCI = { 1,  /* iFirst */
  19200,                               /* iLast */
  1055,                                /* lineNo */
  48,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_emlrtDCI = { 1055,/* lineNo */
  48,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_b_emlrtBCI = { 1,/* iFirst */
  19200,                               /* iLast */
  1056,                                /* lineNo */
  48,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_b_emlrtDCI = { 1056,/* lineNo */
  48,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_c_emlrtBCI = { 1,/* iFirst */
  19200,                               /* iLast */
  1070,                                /* lineNo */
  47,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_c_emlrtDCI = { 1070,/* lineNo */
  47,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_d_emlrtBCI = { 1,/* iFirst */
  19200,                               /* iLast */
  1057,                                /* lineNo */
  48,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_d_emlrtDCI = { 1057,/* lineNo */
  48,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_e_emlrtBCI = { 1,/* iFirst */
  19200,                               /* iLast */
  1058,                                /* lineNo */
  48,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_e_emlrtDCI = { 1058,/* lineNo */
  48,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_f_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1134,                                /* lineNo */
  18,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_f_emlrtDCI = { 1134,/* lineNo */
  18,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_g_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1134,                                /* lineNo */
  34,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_g_emlrtDCI = { 1134,/* lineNo */
  34,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_h_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1134,                                /* lineNo */
  50,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_h_emlrtDCI = { 1134,/* lineNo */
  50,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_i_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1134,                                /* lineNo */
  66,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_i_emlrtDCI = { 1134,/* lineNo */
  66,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_j_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1134,                                /* lineNo */
  11,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c1_j_emlrtDCI = { 1134,/* lineNo */
  11,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_k_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1072,                                /* lineNo */
  52,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_k_emlrtDCI = { 1072,/* lineNo */
  52,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_l_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1072,                                /* lineNo */
  15,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c1_l_emlrtDCI = { 1072,/* lineNo */
  15,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_m_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1060,                                /* lineNo */
  71,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_m_emlrtDCI = { 1060,/* lineNo */
  71,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_n_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1060,                                /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c1_n_emlrtDCI = { 1060,/* lineNo */
  24,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_o_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1061,                                /* lineNo */
  71,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_o_emlrtDCI = { 1061,/* lineNo */
  71,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_p_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1061,                                /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c1_p_emlrtDCI = { 1061,/* lineNo */
  24,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_q_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1062,                                /* lineNo */
  71,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_q_emlrtDCI = { 1062,/* lineNo */
  71,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_r_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1062,                                /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c1_r_emlrtDCI = { 1062,/* lineNo */
  24,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_s_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1063,                                /* lineNo */
  53,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_s_emlrtDCI = { 1063,/* lineNo */
  53,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_t_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  1063,                                /* lineNo */
  15,                                  /* colNo */
  "",                                  /* aName */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c1_t_emlrtDCI = { 1063,/* lineNo */
  15,                                  /* colNo */
  "imhist",                            /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\imhist.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_u_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  54,                                  /* lineNo */
  47,                                  /* colNo */
  "",                                  /* aName */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_u_emlrtDCI = { 54,/* lineNo */
  47,                                  /* colNo */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_v_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  66,                                  /* lineNo */
  27,                                  /* colNo */
  "",                                  /* aName */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_v_emlrtDCI = { 66,/* lineNo */
  27,                                  /* colNo */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_w_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  68,                                  /* lineNo */
  26,                                  /* colNo */
  "",                                  /* aName */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_w_emlrtDCI = { 68,/* lineNo */
  26,                                  /* colNo */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_x_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  68,                                  /* lineNo */
  15,                                  /* colNo */
  "",                                  /* aName */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c1_x_emlrtDCI = { 68,/* lineNo */
  15,                                  /* colNo */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_y_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  70,                                  /* lineNo */
  20,                                  /* colNo */
  "",                                  /* aName */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_y_emlrtDCI = { 70,/* lineNo */
  20,                                  /* colNo */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_ab_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  70,                                  /* lineNo */
  12,                                  /* colNo */
  "",                                  /* aName */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  3                                    /* checkKind */
};

static emlrtDCInfo c1_ab_emlrtDCI = { 70,/* lineNo */
  12,                                  /* colNo */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_bb_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  85,                                  /* lineNo */
  39,                                  /* colNo */
  "",                                  /* aName */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_bb_emlrtDCI = { 85,/* lineNo */
  39,                                  /* colNo */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_cb_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  85,                                  /* lineNo */
  47,                                  /* colNo */
  "",                                  /* aName */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_cb_emlrtDCI = { 85,/* lineNo */
  47,                                  /* colNo */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_db_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  85,                                  /* lineNo */
  62,                                  /* colNo */
  "",                                  /* aName */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_db_emlrtDCI = { 85,/* lineNo */
  62,                                  /* colNo */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_eb_emlrtBCI = { 1,/* iFirst */
  256,                                 /* iLast */
  85,                                  /* lineNo */
  74,                                  /* colNo */
  "",                                  /* aName */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_eb_emlrtDCI = { 85,/* lineNo */
  74,                                  /* colNo */
  "otsuthresh",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2024a\\toolbox\\images\\images\\eml\\otsuthresh.m",/* pName */
  1                                    /* checkKind */
};

/* Function Declarations */
static void initialize_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void initialize_params_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_start_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_terminate_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_setup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_cleanup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void enable_c1_flightControlSystem(SFc1_flightControlSystemInstanceStruct
  *chartInstance);
static void disable_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void sf_gateway_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void ext_mode_exec_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void c1_update_jit_animation_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void c1_do_animation_call_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void set_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance, const mxArray *c1_st);
static void c1_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_nullptr, const char_T *c1_identifier,
  boolean_T c1_y[19200]);
static void c1_b_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId,
  boolean_T c1_y[19200]);
static void c1_slStringInitializeDynamicBuffers
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void c1_chart_data_browse_helper(SFc1_flightControlSystemInstanceStruct
  *chartInstance, int32_T c1_ssIdNumber, const mxArray **c1_mxData, uint8_T
  *c1_isValueTooBig);
static void init_dsm_address_info(SFc1_flightControlSystemInstanceStruct
  *chartInstance);
static void init_simulink_io_address(SFc1_flightControlSystemInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  emlrtStack c1_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  c1_st.tls = chartInstance->c1_fEmlrtCtx;
  emlrtLicenseCheckR2022a(&c1_st, "EMLRT:runTime:MexFunctionNeedsLicense",
    "image_toolbox", 2);
  sim_mode_is_external(chartInstance->S);
  chartInstance->c1_doneDoubleBufferReInit = false;
  chartInstance->c1_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void initialize_params_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_start_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  sim_mode_is_external(chartInstance->S);
}

static void mdl_terminate_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_setup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  static const uint32_T c1_decisionTxtEndIdx = 0U;
  static const uint32_T c1_decisionTxtStartIdx = 0U;
  setDataBrowseFcn(chartInstance->S, (void *)&c1_chart_data_browse_helper);
  chartInstance->c1_RuntimeVar = sfListenerCacheSimStruct(chartInstance->S);
  sfListenerInitializeRuntimeVars(chartInstance->c1_RuntimeVar,
    &chartInstance->c1_IsDebuggerActive,
    &chartInstance->c1_IsSequenceViewerPresent, 0, 0,
    &chartInstance->c1_mlFcnLineNumber, &chartInstance->c1_IsHeatMapPresent, 0);
  sfSetAnimationVectors(chartInstance->S, &chartInstance->c1_JITStateAnimation[0],
                        &chartInstance->c1_JITTransitionAnimation[0]);
  covrtCreateStateflowInstanceData(chartInstance->c1_covrtInstance, 1U, 0U, 1U,
    11U);
  covrtChartInitFcn(chartInstance->c1_covrtInstance, 0U, false, false, false);
  covrtStateInitFcn(chartInstance->c1_covrtInstance, 0U, 0U, false, false, false,
                    0U, &c1_decisionTxtStartIdx, &c1_decisionTxtEndIdx);
  covrtTransInitFcn(chartInstance->c1_covrtInstance, 0U, 0, NULL, NULL, 0U, NULL);
  covrtEmlInitFcn(chartInstance->c1_covrtInstance, "", 4U, 0U, 1U, 0U, 0U, 0U,
                  0U, 0U, 0U, 0U, 0U, 0U);
  covrtEmlFcnInitFcn(chartInstance->c1_covrtInstance, 4U, 0U, 0U,
                     "c1_flightControlSystem", 0, -1, 318);
}

static void mdl_cleanup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  sfListenerLightTerminate(chartInstance->c1_RuntimeVar);
  covrtDeleteStateflowInstanceData(chartInstance->c1_covrtInstance);
}

static void enable_c1_flightControlSystem(SFc1_flightControlSystemInstanceStruct
  *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void sf_gateway_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  static char_T c1_cv4[51] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'V', 'a', 'l', 'i', 'd', 'a', 't', 'e', 'a', 't', 't',
    'r', 'i', 'b', 'u', 't', 'e', 's', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
    'N', 'o', 'n', 'n', 'e', 'g', 'a', 't', 'i', 'v', 'e' };

  static char_T c1_cv1[46] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'V', 'a', 'l', 'i', 'd', 'a', 't', 'e', 'a', 't', 't',
    'r', 'i', 'b', 'u', 't', 'e', 's', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
    'F', 'i', 'n', 'i', 't', 'e' };

  static char_T c1_cv3[37] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'o', 't', 's',
    'u', 't', 'h', 'r', 'e', 's', 'h', ':', 'e', 'x', 'p', 'e', 'c', 't', 'e',
    'd', 'N', 'o', 'n', 'n', 'e', 'g', 'a', 't', 'i', 'v', 'e' };

  static char_T c1_cv[32] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'o', 't', 's',
    'u', 't', 'h', 'r', 'e', 's', 'h', ':', 'e', 'x', 'p', 'e', 'c', 't', 'e',
    'd', 'F', 'i', 'n', 'i', 't', 'e' };

  static char_T c1_cv2[6] = { 'C', 'O', 'U', 'N', 'T', 'S' };

  static char_T c1_cv5[6] = { 'C', 'O', 'U', 'N', 'T', 'S' };

  emlrtStack c1_b_st;
  emlrtStack c1_c_st;
  emlrtStack c1_d_st;
  emlrtStack c1_e_st;
  emlrtStack c1_f_st;
  emlrtStack c1_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  const mxArray *c1_b_y = NULL;
  const mxArray *c1_c_y = NULL;
  const mxArray *c1_d_y = NULL;
  const mxArray *c1_e_y = NULL;
  const mxArray *c1_f_y = NULL;
  const mxArray *c1_g_y = NULL;
  real_T c1_localBins1[256];
  real_T c1_localBins2[256];
  real_T c1_localBins3[256];
  real_T c1_y[256];
  real_T c1_T;
  real_T c1_b_idx;
  real_T c1_b_k;
  real_T c1_b_x;
  real_T c1_c_x;
  real_T c1_d;
  real_T c1_d1;
  real_T c1_d10;
  real_T c1_d11;
  real_T c1_d12;
  real_T c1_d13;
  real_T c1_d14;
  real_T c1_d15;
  real_T c1_d16;
  real_T c1_d17;
  real_T c1_d2;
  real_T c1_d3;
  real_T c1_d4;
  real_T c1_d5;
  real_T c1_d6;
  real_T c1_d7;
  real_T c1_d8;
  real_T c1_d9;
  real_T c1_d_i;
  real_T c1_d_k;
  real_T c1_d_p;
  real_T c1_d_x;
  real_T c1_e_x;
  real_T c1_f_k;
  real_T c1_f_x;
  real_T c1_g_a;
  real_T c1_g_c;
  real_T c1_g_x;
  real_T c1_h_a;
  real_T c1_i_a;
  real_T c1_j_a;
  real_T c1_k_a;
  real_T c1_maxval;
  real_T c1_mu_t;
  real_T c1_num_elems;
  real_T c1_num_maxval;
  real_T c1_out;
  real_T c1_sigma_b_squared;
  real_T c1_t;
  real_T c1_x;
  int32_T c1_a;
  int32_T c1_b_a;
  int32_T c1_b_c;
  int32_T c1_b_i;
  int32_T c1_b_j;
  int32_T c1_c;
  int32_T c1_c_a;
  int32_T c1_c_c;
  int32_T c1_c_i;
  int32_T c1_c_j;
  int32_T c1_c_k;
  int32_T c1_d_a;
  int32_T c1_d_c;
  int32_T c1_d_j;
  int32_T c1_e_a;
  int32_T c1_e_c;
  int32_T c1_e_k;
  int32_T c1_f_a;
  int32_T c1_f_c;
  int32_T c1_g_k;
  int32_T c1_h_c;
  int32_T c1_h_k;
  int32_T c1_i;
  int32_T c1_i1;
  int32_T c1_i10;
  int32_T c1_i11;
  int32_T c1_i12;
  int32_T c1_i13;
  int32_T c1_i14;
  int32_T c1_i15;
  int32_T c1_i16;
  int32_T c1_i17;
  int32_T c1_i18;
  int32_T c1_i19;
  int32_T c1_i2;
  int32_T c1_i20;
  int32_T c1_i21;
  int32_T c1_i22;
  int32_T c1_i23;
  int32_T c1_i24;
  int32_T c1_i25;
  int32_T c1_i26;
  int32_T c1_i27;
  int32_T c1_i28;
  int32_T c1_i29;
  int32_T c1_i3;
  int32_T c1_i30;
  int32_T c1_i31;
  int32_T c1_i32;
  int32_T c1_i33;
  int32_T c1_i34;
  int32_T c1_i35;
  int32_T c1_i36;
  int32_T c1_i37;
  int32_T c1_i38;
  int32_T c1_i4;
  int32_T c1_i5;
  int32_T c1_i6;
  int32_T c1_i7;
  int32_T c1_i8;
  int32_T c1_i9;
  int32_T c1_i_c;
  int32_T c1_idx;
  int32_T c1_idx1;
  int32_T c1_idx2;
  int32_T c1_idx3;
  int32_T c1_idx4;
  int32_T c1_iy;
  int32_T c1_j;
  int32_T c1_j_c;
  int32_T c1_k;
  int32_T c1_k_c;
  int32_T c1_l_a;
  int32_T c1_m_a;
  int32_T c1_n_a;
  int32_T c1_o_a;
  uint8_T c1_rgbImage[57600];
  uint8_T c1_grayImage[19200];
  boolean_T c1_b;
  boolean_T c1_b1;
  boolean_T c1_b2;
  boolean_T c1_b3;
  boolean_T c1_b4;
  boolean_T c1_b5;
  boolean_T c1_b_b;
  boolean_T c1_b_p;
  boolean_T c1_c_b;
  boolean_T c1_c_p;
  boolean_T c1_d_b;
  boolean_T c1_e_b;
  boolean_T c1_exitg1;
  boolean_T c1_f_b;
  boolean_T c1_isfinite_maxval;
  boolean_T c1_p;
  c1_st.tls = chartInstance->c1_fEmlrtCtx;
  c1_b_st.prev = &c1_st;
  c1_b_st.tls = c1_st.tls;
  c1_c_st.prev = &c1_b_st;
  c1_c_st.tls = c1_b_st.tls;
  c1_d_st.prev = &c1_c_st;
  c1_d_st.tls = c1_c_st.tls;
  c1_e_st.prev = &c1_d_st;
  c1_e_st.tls = c1_d_st.tls;
  c1_f_st.prev = &c1_e_st;
  c1_f_st.tls = c1_e_st.tls;
  for (c1_i = 0; c1_i < 19200; c1_i++) {
    covrtSigUpdateFcn(chartInstance->c1_covrtInstance, 2U, (real_T)
                      (*chartInstance->c1_B)[c1_i]);
  }

  for (c1_i1 = 0; c1_i1 < 19200; c1_i1++) {
    covrtSigUpdateFcn(chartInstance->c1_covrtInstance, 1U, (real_T)
                      (*chartInstance->c1_G)[c1_i1]);
  }

  for (c1_i2 = 0; c1_i2 < 19200; c1_i2++) {
    covrtSigUpdateFcn(chartInstance->c1_covrtInstance, 0U, (real_T)
                      (*chartInstance->c1_R)[c1_i2]);
  }

  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c1_JITTransitionAnimation[0] = 0U;
  chartInstance->c1_sfEvent = CALL_EVENT;
  covrtEmlFcnEval(chartInstance->c1_covrtInstance, 4U, 0, 0);
  c1_iy = -1;
  for (c1_j = 0; c1_j < 19200; c1_j++) {
    c1_c_j = c1_j;
    c1_iy++;
    c1_rgbImage[c1_iy] = (*chartInstance->c1_R)[c1_c_j];
  }

  for (c1_b_j = 0; c1_b_j < 19200; c1_b_j++) {
    c1_c_j = c1_b_j;
    c1_iy++;
    c1_rgbImage[c1_iy] = (*chartInstance->c1_G)[c1_c_j];
  }

  for (c1_d_j = 0; c1_d_j < 19200; c1_d_j++) {
    c1_c_j = c1_d_j;
    c1_iy++;
    c1_rgbImage[c1_iy] = (*chartInstance->c1_B)[c1_c_j];
  }

  c1_b_st.site = &c1_emlrtRSI;
  c1_c_st.site = &c1_c_emlrtRSI;
  rgb2gray_tbb_uint8(&c1_rgbImage[0], 19200.0, &c1_grayImage[0], true);
  c1_b_st.site = &c1_b_emlrtRSI;
  c1_c_st.site = &c1_d_emlrtRSI;
  c1_d_st.site = &c1_e_emlrtRSI;
  c1_e_st.site = &c1_f_emlrtRSI;
  c1_f_st.site = &c1_g_emlrtRSI;
  c1_out = 1.0;
  getnumcores(&c1_out);
  c1_f_st.site = &c1_h_emlrtRSI;
  for (c1_i3 = 0; c1_i3 < 256; c1_i3++) {
    c1_y[c1_i3] = 0.0;
  }

  for (c1_i4 = 0; c1_i4 < 256; c1_i4++) {
    c1_localBins1[c1_i4] = 0.0;
  }

  for (c1_i5 = 0; c1_i5 < 256; c1_i5++) {
    c1_localBins2[c1_i5] = 0.0;
  }

  for (c1_i6 = 0; c1_i6 < 256; c1_i6++) {
    c1_localBins3[c1_i6] = 0.0;
  }

  for (c1_b_i = 1; c1_b_i + 3 <= 19200; c1_b_i += 4) {
    c1_d = (real_T)c1_b_i;
    if (c1_d != (real_T)(int32_T)muDoubleScalarFloor(c1_d)) {
      emlrtIntegerCheckR2012b(c1_d, &c1_emlrtDCI, &c1_f_st);
    }

    c1_i7 = (int32_T)muDoubleScalarFloor(c1_d);
    if ((c1_i7 < 1) || (c1_i7 > 19200)) {
      emlrtDynamicBoundsCheckR2012b(c1_i7, 1, 19200, &c1_emlrtBCI, &c1_f_st);
    }

    c1_idx1 = c1_grayImage[c1_i7 - 1];
    c1_d2 = (real_T)(c1_b_i + 1);
    if (c1_d2 != (real_T)(int32_T)muDoubleScalarFloor(c1_d2)) {
      emlrtIntegerCheckR2012b(c1_d2, &c1_b_emlrtDCI, &c1_f_st);
    }

    c1_i10 = (int32_T)muDoubleScalarFloor(c1_d2);
    if ((c1_i10 < 1) || (c1_i10 > 19200)) {
      emlrtDynamicBoundsCheckR2012b(c1_i10, 1, 19200, &c1_b_emlrtBCI, &c1_f_st);
    }

    c1_idx2 = c1_grayImage[c1_i10 - 1];
    c1_d4 = (real_T)(c1_b_i + 2);
    if (c1_d4 != (real_T)(int32_T)muDoubleScalarFloor(c1_d4)) {
      emlrtIntegerCheckR2012b(c1_d4, &c1_d_emlrtDCI, &c1_f_st);
    }

    c1_i14 = (int32_T)muDoubleScalarFloor(c1_d4);
    if ((c1_i14 < 1) || (c1_i14 > 19200)) {
      emlrtDynamicBoundsCheckR2012b(c1_i14, 1, 19200, &c1_d_emlrtBCI, &c1_f_st);
    }

    c1_idx3 = c1_grayImage[c1_i14 - 1];
    c1_d6 = (real_T)(c1_b_i + 3);
    if (c1_d6 != (real_T)(int32_T)muDoubleScalarFloor(c1_d6)) {
      emlrtIntegerCheckR2012b(c1_d6, &c1_e_emlrtDCI, &c1_f_st);
    }

    c1_i17 = (int32_T)muDoubleScalarFloor(c1_d6);
    if ((c1_i17 < 1) || (c1_i17 > 19200)) {
      emlrtDynamicBoundsCheckR2012b(c1_i17, 1, 19200, &c1_e_emlrtBCI, &c1_f_st);
    }

    c1_idx4 = c1_grayImage[c1_i17 - 1];
    c1_c_a = c1_idx1 + 1;
    c1_c_c = c1_c_a;
    c1_d_a = c1_idx1 + 1;
    c1_d_c = c1_d_a;
    c1_d7 = (real_T)c1_d_c;
    if (c1_d7 != (real_T)(int32_T)muDoubleScalarFloor(c1_d7)) {
      emlrtIntegerCheckR2012b(c1_d7, &c1_m_emlrtDCI, &c1_f_st);
    }

    c1_i20 = (int32_T)muDoubleScalarFloor(c1_d7);
    if ((c1_i20 < 1) || (c1_i20 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i20, 1, 256, &c1_m_emlrtBCI, &c1_f_st);
    }

    c1_d8 = (real_T)c1_c_c;
    if (c1_d8 != (real_T)(int32_T)muDoubleScalarFloor(c1_d8)) {
      emlrtIntegerCheckR2012b(c1_d8, &c1_n_emlrtDCI, &c1_f_st);
    }

    c1_i22 = (int32_T)muDoubleScalarFloor(c1_d8);
    if ((c1_i22 < 1) || (c1_i22 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i22, 1, 256, &c1_n_emlrtBCI, &c1_f_st);
    }

    c1_localBins1[c1_i22 - 1] = c1_localBins1[c1_i20 - 1] + 1.0;
    c1_e_a = c1_idx2 + 1;
    c1_e_c = c1_e_a;
    c1_f_a = c1_idx2 + 1;
    c1_f_c = c1_f_a;
    c1_d10 = (real_T)c1_f_c;
    if (c1_d10 != (real_T)(int32_T)muDoubleScalarFloor(c1_d10)) {
      emlrtIntegerCheckR2012b(c1_d10, &c1_o_emlrtDCI, &c1_f_st);
    }

    c1_i27 = (int32_T)muDoubleScalarFloor(c1_d10);
    if ((c1_i27 < 1) || (c1_i27 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i27, 1, 256, &c1_o_emlrtBCI, &c1_f_st);
    }

    c1_d13 = (real_T)c1_e_c;
    if (c1_d13 != (real_T)(int32_T)muDoubleScalarFloor(c1_d13)) {
      emlrtIntegerCheckR2012b(c1_d13, &c1_p_emlrtDCI, &c1_f_st);
    }

    c1_i31 = (int32_T)muDoubleScalarFloor(c1_d13);
    if ((c1_i31 < 1) || (c1_i31 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i31, 1, 256, &c1_p_emlrtBCI, &c1_f_st);
    }

    c1_localBins2[c1_i31 - 1] = c1_localBins2[c1_i27 - 1] + 1.0;
    c1_l_a = c1_idx3 + 1;
    c1_h_c = c1_l_a;
    c1_m_a = c1_idx3 + 1;
    c1_i_c = c1_m_a;
    c1_d14 = (real_T)c1_i_c;
    if (c1_d14 != (real_T)(int32_T)muDoubleScalarFloor(c1_d14)) {
      emlrtIntegerCheckR2012b(c1_d14, &c1_q_emlrtDCI, &c1_f_st);
    }

    c1_i35 = (int32_T)muDoubleScalarFloor(c1_d14);
    if ((c1_i35 < 1) || (c1_i35 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i35, 1, 256, &c1_q_emlrtBCI, &c1_f_st);
    }

    c1_d15 = (real_T)c1_h_c;
    if (c1_d15 != (real_T)(int32_T)muDoubleScalarFloor(c1_d15)) {
      emlrtIntegerCheckR2012b(c1_d15, &c1_r_emlrtDCI, &c1_f_st);
    }

    c1_i36 = (int32_T)muDoubleScalarFloor(c1_d15);
    if ((c1_i36 < 1) || (c1_i36 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i36, 1, 256, &c1_r_emlrtBCI, &c1_f_st);
    }

    c1_localBins3[c1_i36 - 1] = c1_localBins3[c1_i35 - 1] + 1.0;
    c1_n_a = c1_idx4 + 1;
    c1_j_c = c1_n_a;
    c1_o_a = c1_idx4 + 1;
    c1_k_c = c1_o_a;
    c1_d16 = (real_T)c1_k_c;
    if (c1_d16 != (real_T)(int32_T)muDoubleScalarFloor(c1_d16)) {
      emlrtIntegerCheckR2012b(c1_d16, &c1_s_emlrtDCI, &c1_f_st);
    }

    c1_i37 = (int32_T)muDoubleScalarFloor(c1_d16);
    if ((c1_i37 < 1) || (c1_i37 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i37, 1, 256, &c1_s_emlrtBCI, &c1_f_st);
    }

    c1_d17 = (real_T)c1_j_c;
    if (c1_d17 != (real_T)(int32_T)muDoubleScalarFloor(c1_d17)) {
      emlrtIntegerCheckR2012b(c1_d17, &c1_t_emlrtDCI, &c1_f_st);
    }

    c1_i38 = (int32_T)muDoubleScalarFloor(c1_d17);
    if ((c1_i38 < 1) || (c1_i38 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i38, 1, 256, &c1_t_emlrtBCI, &c1_f_st);
    }

    c1_y[c1_i38 - 1] = c1_y[c1_i37 - 1] + 1.0;
  }

  while (c1_b_i <= 19200) {
    c1_d1 = (real_T)c1_b_i;
    if (c1_d1 != (real_T)(int32_T)muDoubleScalarFloor(c1_d1)) {
      emlrtIntegerCheckR2012b(c1_d1, &c1_c_emlrtDCI, &c1_f_st);
    }

    c1_i8 = (int32_T)muDoubleScalarFloor(c1_d1);
    if ((c1_i8 < 1) || (c1_i8 > 19200)) {
      emlrtDynamicBoundsCheckR2012b(c1_i8, 1, 19200, &c1_c_emlrtBCI, &c1_f_st);
    }

    c1_idx = c1_grayImage[c1_i8 - 1];
    c1_a = c1_idx + 1;
    c1_c = c1_a;
    c1_b_a = c1_idx + 1;
    c1_b_c = c1_b_a;
    c1_d3 = (real_T)c1_b_c;
    if (c1_d3 != (real_T)(int32_T)muDoubleScalarFloor(c1_d3)) {
      emlrtIntegerCheckR2012b(c1_d3, &c1_k_emlrtDCI, &c1_f_st);
    }

    c1_i12 = (int32_T)muDoubleScalarFloor(c1_d3);
    if ((c1_i12 < 1) || (c1_i12 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i12, 1, 256, &c1_k_emlrtBCI, &c1_f_st);
    }

    c1_d5 = (real_T)c1_c;
    if (c1_d5 != (real_T)(int32_T)muDoubleScalarFloor(c1_d5)) {
      emlrtIntegerCheckR2012b(c1_d5, &c1_l_emlrtDCI, &c1_f_st);
    }

    c1_i16 = (int32_T)muDoubleScalarFloor(c1_d5);
    if ((c1_i16 < 1) || (c1_i16 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i16, 1, 256, &c1_l_emlrtBCI, &c1_f_st);
    }

    c1_y[c1_i16 - 1] = c1_y[c1_i12 - 1] + 1.0;
    c1_b_i++;
  }

  for (c1_c_i = 0; c1_c_i < 256; c1_c_i++) {
    c1_d_i = 1.0 + (real_T)c1_c_i;
    if (c1_d_i != (real_T)(int32_T)muDoubleScalarFloor(c1_d_i)) {
      emlrtIntegerCheckR2012b(c1_d_i, &c1_f_emlrtDCI, &c1_f_st);
    }

    c1_i9 = (int32_T)c1_d_i;
    if ((c1_i9 < 1) || (c1_i9 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i9, 1, 256, &c1_f_emlrtBCI, &c1_f_st);
    }

    if (c1_d_i != (real_T)(int32_T)muDoubleScalarFloor(c1_d_i)) {
      emlrtIntegerCheckR2012b(c1_d_i, &c1_g_emlrtDCI, &c1_f_st);
    }

    c1_i11 = (int32_T)c1_d_i;
    if ((c1_i11 < 1) || (c1_i11 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i11, 1, 256, &c1_g_emlrtBCI, &c1_f_st);
    }

    if (c1_d_i != (real_T)(int32_T)muDoubleScalarFloor(c1_d_i)) {
      emlrtIntegerCheckR2012b(c1_d_i, &c1_h_emlrtDCI, &c1_f_st);
    }

    c1_i13 = (int32_T)c1_d_i;
    if ((c1_i13 < 1) || (c1_i13 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i13, 1, 256, &c1_h_emlrtBCI, &c1_f_st);
    }

    if (c1_d_i != (real_T)(int32_T)muDoubleScalarFloor(c1_d_i)) {
      emlrtIntegerCheckR2012b(c1_d_i, &c1_i_emlrtDCI, &c1_f_st);
    }

    c1_i15 = (int32_T)c1_d_i;
    if ((c1_i15 < 1) || (c1_i15 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i15, 1, 256, &c1_i_emlrtBCI, &c1_f_st);
    }

    if (c1_d_i != (real_T)(int32_T)muDoubleScalarFloor(c1_d_i)) {
      emlrtIntegerCheckR2012b(c1_d_i, &c1_j_emlrtDCI, &c1_f_st);
    }

    c1_i18 = (int32_T)c1_d_i;
    if ((c1_i18 < 1) || (c1_i18 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i18, 1, 256, &c1_j_emlrtBCI, &c1_f_st);
    }

    c1_y[c1_i18 - 1] = ((c1_y[c1_i9 - 1] + c1_localBins1[c1_i11 - 1]) +
                        c1_localBins2[c1_i13 - 1]) + c1_localBins3[c1_i15 - 1];
  }

  c1_d_st.site = &c1_e_emlrtRSI;
  c1_e_st.site = &c1_k_emlrtRSI;
  c1_f_st.site = &c1_m_emlrtRSI;
  c1_p = true;
  c1_k = 0;
  c1_exitg1 = false;
  while ((!c1_exitg1) && (c1_k < 256)) {
    c1_b_k = 1.0 + (real_T)c1_k;
    c1_x = c1_y[(int32_T)c1_b_k - 1];
    c1_b_x = c1_x;
    c1_b_b = muDoubleScalarIsInf(c1_b_x);
    c1_b1 = !c1_b_b;
    c1_c_x = c1_x;
    c1_c_b = muDoubleScalarIsNaN(c1_c_x);
    c1_b2 = !c1_c_b;
    c1_d_b = (c1_b1 && c1_b2);
    if (c1_d_b) {
      c1_k++;
    } else {
      c1_p = false;
      c1_exitg1 = true;
    }
  }

  if (c1_p) {
    c1_b = true;
  } else {
    c1_b = false;
  }

  if (!c1_b) {
    c1_b_y = NULL;
    sf_mex_assign(&c1_b_y, sf_mex_create("y", c1_cv, 10, 0U, 1, 0U, 2, 1, 32),
                  false);
    c1_c_y = NULL;
    sf_mex_assign(&c1_c_y, sf_mex_create("y", c1_cv1, 10, 0U, 1, 0U, 2, 1, 46),
                  false);
    c1_d_y = NULL;
    sf_mex_assign(&c1_d_y, sf_mex_create("y", c1_cv2, 10, 0U, 1, 0U, 2, 1, 6),
                  false);
    sf_mex_call(&c1_f_st, &c1_emlrtMCI, "error", 0U, 2U, 14, c1_b_y, 14,
                sf_mex_call(&c1_f_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_f_st, NULL, "message", 1U, 2U, 14, c1_c_y, 14, c1_d_y)));
  }

  c1_f_st.site = &c1_m_emlrtRSI;
  c1_b_p = true;
  c1_c_k = 0;
  c1_exitg1 = false;
  while ((!c1_exitg1) && (c1_c_k < 256)) {
    c1_d_k = 1.0 + (real_T)c1_c_k;
    c1_d_x = c1_y[(int32_T)c1_d_k - 1];
    c1_c_p = !(c1_d_x < 0.0);
    if (c1_c_p) {
      c1_c_k++;
    } else {
      c1_b_p = false;
      c1_exitg1 = true;
    }
  }

  if (c1_b_p) {
    c1_b3 = true;
  } else {
    c1_b3 = false;
  }

  if (!c1_b3) {
    c1_e_y = NULL;
    sf_mex_assign(&c1_e_y, sf_mex_create("y", c1_cv3, 10, 0U, 1, 0U, 2, 1, 37),
                  false);
    c1_f_y = NULL;
    sf_mex_assign(&c1_f_y, sf_mex_create("y", c1_cv4, 10, 0U, 1, 0U, 2, 1, 51),
                  false);
    c1_g_y = NULL;
    sf_mex_assign(&c1_g_y, sf_mex_create("y", c1_cv5, 10, 0U, 1, 0U, 2, 1, 6),
                  false);
    sf_mex_call(&c1_f_st, &c1_b_emlrtMCI, "error", 0U, 2U, 14, c1_e_y, 14,
                sf_mex_call(&c1_f_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_f_st, NULL, "message", 1U, 2U, 14, c1_f_y, 14, c1_g_y)));
  }

  c1_num_elems = 0.0;
  for (c1_e_k = 0; c1_e_k < 256; c1_e_k++) {
    c1_f_k = 1.0 + (real_T)c1_e_k;
    if (c1_f_k != (real_T)(int32_T)muDoubleScalarFloor(c1_f_k)) {
      emlrtIntegerCheckR2012b(c1_f_k, &c1_u_emlrtDCI, &c1_d_st);
    }

    c1_i19 = (int32_T)c1_f_k;
    if ((c1_i19 < 1) || (c1_i19 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i19, 1, 256, &c1_u_emlrtBCI, &c1_d_st);
    }

    c1_num_elems += c1_y[c1_i19 - 1];
  }

  c1_localBins1[0] = c1_y[0] / c1_num_elems;
  c1_localBins2[0] = c1_localBins1[0];
  for (c1_g_k = 0; c1_g_k < 255; c1_g_k++) {
    c1_f_k = 2.0 + (real_T)c1_g_k;
    if (c1_f_k != (real_T)(int32_T)muDoubleScalarFloor(c1_f_k)) {
      emlrtIntegerCheckR2012b(c1_f_k, &c1_v_emlrtDCI, &c1_d_st);
    }

    c1_i21 = (int32_T)c1_f_k;
    if ((c1_i21 < 1) || (c1_i21 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i21, 1, 256, &c1_v_emlrtBCI, &c1_d_st);
    }

    c1_d_p = c1_y[c1_i21 - 1] / c1_num_elems;
    c1_d9 = c1_f_k - 1.0;
    if (c1_d9 != (real_T)(int32_T)muDoubleScalarFloor(c1_d9)) {
      emlrtIntegerCheckR2012b(c1_d9, &c1_w_emlrtDCI, &c1_d_st);
    }

    c1_i24 = (int32_T)c1_d9;
    if ((c1_i24 < 1) || (c1_i24 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i24, 1, 256, &c1_w_emlrtBCI, &c1_d_st);
    }

    if (c1_f_k != (real_T)(int32_T)muDoubleScalarFloor(c1_f_k)) {
      emlrtIntegerCheckR2012b(c1_f_k, &c1_x_emlrtDCI, &c1_d_st);
    }

    c1_i26 = (int32_T)c1_f_k;
    if ((c1_i26 < 1) || (c1_i26 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i26, 1, 256, &c1_x_emlrtBCI, &c1_d_st);
    }

    c1_localBins1[c1_i26 - 1] = c1_localBins1[c1_i24 - 1] + c1_d_p;
    c1_d12 = c1_f_k - 1.0;
    if (c1_d12 != (real_T)(int32_T)muDoubleScalarFloor(c1_d12)) {
      emlrtIntegerCheckR2012b(c1_d12, &c1_y_emlrtDCI, &c1_d_st);
    }

    c1_i30 = (int32_T)c1_d12;
    if ((c1_i30 < 1) || (c1_i30 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i30, 1, 256, &c1_y_emlrtBCI, &c1_d_st);
    }

    if (c1_f_k != (real_T)(int32_T)muDoubleScalarFloor(c1_f_k)) {
      emlrtIntegerCheckR2012b(c1_f_k, &c1_ab_emlrtDCI, &c1_d_st);
    }

    c1_i33 = (int32_T)c1_f_k;
    if ((c1_i33 < 1) || (c1_i33 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i33, 1, 256, &c1_ab_emlrtBCI, &c1_d_st);
    }

    c1_localBins2[c1_i33 - 1] = c1_localBins2[c1_i30 - 1] + c1_d_p * c1_f_k;
  }

  c1_mu_t = c1_localBins2[255];
  c1_maxval = rtMinusInf;
  c1_b_idx = 0.0;
  c1_num_maxval = 0.0;
  for (c1_h_k = 0; c1_h_k < 255; c1_h_k++) {
    c1_f_k = 1.0 + (real_T)c1_h_k;
    c1_e_st.site = &c1_l_emlrtRSI;
    if (c1_f_k != (real_T)(int32_T)muDoubleScalarFloor(c1_f_k)) {
      emlrtIntegerCheckR2012b(c1_f_k, &c1_bb_emlrtDCI, &c1_e_st);
    }

    c1_i23 = (int32_T)c1_f_k;
    if ((c1_i23 < 1) || (c1_i23 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i23, 1, 256, &c1_bb_emlrtBCI, &c1_e_st);
    }

    if (c1_f_k != (real_T)(int32_T)muDoubleScalarFloor(c1_f_k)) {
      emlrtIntegerCheckR2012b(c1_f_k, &c1_cb_emlrtDCI, &c1_e_st);
    }

    c1_i25 = (int32_T)c1_f_k;
    if ((c1_i25 < 1) || (c1_i25 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i25, 1, 256, &c1_cb_emlrtBCI, &c1_e_st);
    }

    c1_g_a = c1_mu_t * c1_localBins1[c1_i23 - 1] - c1_localBins2[c1_i25 - 1];
    c1_f_st.site = &c1_n_emlrtRSI;
    c1_h_a = c1_g_a;
    c1_i_a = c1_h_a;
    c1_j_a = c1_i_a;
    c1_k_a = c1_j_a;
    c1_g_c = c1_k_a * c1_k_a;
    if (c1_f_k != (real_T)(int32_T)muDoubleScalarFloor(c1_f_k)) {
      emlrtIntegerCheckR2012b(c1_f_k, &c1_db_emlrtDCI, &c1_d_st);
    }

    c1_i32 = (int32_T)c1_f_k;
    if ((c1_i32 < 1) || (c1_i32 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i32, 1, 256, &c1_db_emlrtBCI, &c1_d_st);
    }

    if (c1_f_k != (real_T)(int32_T)muDoubleScalarFloor(c1_f_k)) {
      emlrtIntegerCheckR2012b(c1_f_k, &c1_eb_emlrtDCI, &c1_d_st);
    }

    c1_i34 = (int32_T)c1_f_k;
    if ((c1_i34 < 1) || (c1_i34 > 256)) {
      emlrtDynamicBoundsCheckR2012b(c1_i34, 1, 256, &c1_eb_emlrtBCI, &c1_d_st);
    }

    c1_sigma_b_squared = c1_g_c / (c1_localBins1[c1_i32 - 1] * (1.0 -
      c1_localBins1[c1_i34 - 1]));
    if (c1_sigma_b_squared > c1_maxval) {
      c1_maxval = c1_sigma_b_squared;
      c1_b_idx = c1_f_k;
      c1_num_maxval = 1.0;
    } else if (c1_sigma_b_squared == c1_maxval) {
      c1_b_idx += c1_f_k;
      c1_num_maxval++;
    }
  }

  c1_e_x = c1_maxval;
  c1_f_x = c1_e_x;
  c1_e_b = muDoubleScalarIsInf(c1_f_x);
  c1_b4 = !c1_e_b;
  c1_g_x = c1_e_x;
  c1_f_b = muDoubleScalarIsNaN(c1_g_x);
  c1_b5 = !c1_f_b;
  c1_isfinite_maxval = (c1_b4 && c1_b5);
  if (c1_isfinite_maxval) {
    c1_b_idx /= c1_num_maxval;
    c1_t = (c1_b_idx - 1.0) / 255.0;
  } else {
    c1_t = 0.0;
  }

  c1_T = c1_t;
  c1_d11 = 255.0 * c1_T;
  for (c1_i28 = 0; c1_i28 < 19200; c1_i28++) {
    (*chartInstance->c1_bwImage)[c1_i28] = ((real_T)c1_grayImage[c1_i28] >
      c1_d11);
  }

  for (c1_i29 = 0; c1_i29 < 19200; c1_i29++) {
    covrtSigUpdateFcn(chartInstance->c1_covrtInstance, 3U, (real_T)
                      (*chartInstance->c1_bwImage)[c1_i29]);
  }
}

static void ext_mode_exec_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c1_update_jit_animation_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c1_do_animation_call_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static const mxArray *get_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  const mxArray *c1_b_y = NULL;
  const mxArray *c1_st = NULL;
  const mxArray *c1_y = NULL;
  c1_st = NULL;
  c1_y = NULL;
  sf_mex_assign(&c1_y, sf_mex_createcellmatrix(1, 1), false);
  c1_b_y = NULL;
  sf_mex_assign(&c1_b_y, sf_mex_create("y", *chartInstance->c1_bwImage, 11, 0U,
    1, 0U, 2, 120, 160), false);
  sf_mex_setcell(c1_y, 0, c1_b_y);
  sf_mex_assign(&c1_st, c1_y, false);
  return c1_st;
}

static void set_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance, const mxArray *c1_st)
{
  const mxArray *c1_u;
  int32_T c1_i;
  boolean_T c1_bv[19200];
  chartInstance->c1_doneDoubleBufferReInit = true;
  c1_u = sf_mex_dup(c1_st);
  c1_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 0)),
                      "bwImage", c1_bv);
  for (c1_i = 0; c1_i < 19200; c1_i++) {
    (*chartInstance->c1_bwImage)[c1_i] = c1_bv[c1_i];
  }

  sf_mex_destroy(&c1_u);
  sf_mex_destroy(&c1_st);
}

const mxArray *sf_c1_flightControlSystem_get_eml_resolved_functions_info(void)
{
  const mxArray *c1_nameCaptureInfo = NULL;
  c1_nameCaptureInfo = NULL;
  sf_mex_assign(&c1_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1, 0U, 2, 0, 1), false);
  return c1_nameCaptureInfo;
}

static void c1_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_nullptr, const char_T *c1_identifier,
  boolean_T c1_y[19200])
{
  emlrtMsgIdentifier c1_thisId;
  c1_thisId.fIdentifier = (const char_T *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c1_nullptr), &c1_thisId, c1_y);
  sf_mex_destroy(&c1_nullptr);
}

static void c1_b_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId,
  boolean_T c1_y[19200])
{
  int32_T c1_i;
  boolean_T c1_bv[19200];
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), c1_bv, 1, 11, 0U, 1, 0U, 2, 120,
                160);
  for (c1_i = 0; c1_i < 19200; c1_i++) {
    c1_y[c1_i] = c1_bv[c1_i];
  }

  sf_mex_destroy(&c1_u);
}

static void c1_slStringInitializeDynamicBuffers
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c1_chart_data_browse_helper(SFc1_flightControlSystemInstanceStruct
  *chartInstance, int32_T c1_ssIdNumber, const mxArray **c1_mxData, uint8_T
  *c1_isValueTooBig)
{
  *c1_mxData = NULL;
  *c1_mxData = NULL;
  *c1_isValueTooBig = 0U;
  switch (c1_ssIdNumber) {
   case 4U:
    sf_mex_assign(c1_mxData, sf_mex_create("mxData", *chartInstance->c1_R, 3, 0U,
      1, 0U, 2, 120, 160), false);
    break;

   case 5U:
    sf_mex_assign(c1_mxData, sf_mex_create("mxData", *chartInstance->c1_bwImage,
      11, 0U, 1, 0U, 2, 120, 160), false);
    break;

   case 6U:
    sf_mex_assign(c1_mxData, sf_mex_create("mxData", *chartInstance->c1_G, 3, 0U,
      1, 0U, 2, 120, 160), false);
    break;

   case 7U:
    sf_mex_assign(c1_mxData, sf_mex_create("mxData", *chartInstance->c1_B, 3, 0U,
      1, 0U, 2, 120, 160), false);
    break;
  }
}

static void init_dsm_address_info(SFc1_flightControlSystemInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc1_flightControlSystemInstanceStruct
  *chartInstance)
{
  chartInstance->c1_covrtInstance = (CovrtStateflowInstance *)
    sfrtGetCovrtInstance(chartInstance->S);
  chartInstance->c1_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c1_R = (uint8_T (*)[19200])ssGetInputPortSignal_wrapper
    (chartInstance->S, 0);
  chartInstance->c1_bwImage = (boolean_T (*)[19200])
    ssGetOutputPortSignal_wrapper(chartInstance->S, 1);
  chartInstance->c1_G = (uint8_T (*)[19200])ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c1_B = (uint8_T (*)[19200])ssGetInputPortSignal_wrapper
    (chartInstance->S, 2);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c1_flightControlSystem_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2922776674U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3322996396U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1920275688U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(4010048744U);
}

mxArray *sf_c1_flightControlSystem_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,2);
  mxSetCell(mxcell3p, 0, mxCreateString(
             "images.internal.coder.buildable.Rgb2grayBuildable"));
  mxSetCell(mxcell3p, 1, mxCreateString(
             "images.internal.coder.buildable.GetnumcoresBuildable"));
  return(mxcell3p);
}

mxArray *sf_c1_flightControlSystem_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("late");
  mxArray *fallbackReason = mxCreateString("ir_function_calls");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("rgb2gray_tbb_uint8");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c1_flightControlSystem_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c1_flightControlSystem(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNpjYPT0ZQACPiBWYGRgYAPSHEDMxAABrFA+IxKGiLPAxRWAuKSyIBUkXlyU7JkCpPMSc8H8xNI"
    "Kz7y0fLD5FgwI89kImM8JFYeAD/aU6RdxQNfPgkU/O5J+ASg/qdwzNzE9Fex+EAAAuCEPEw=="
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c1_flightControlSystem_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "sMDPfNk04nyzqeSuh2aXrCH";
}

static void sf_opaque_initialize_c1_flightControlSystem(void *chartInstanceVar)
{
  initialize_params_c1_flightControlSystem
    ((SFc1_flightControlSystemInstanceStruct*) chartInstanceVar);
  initialize_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c1_flightControlSystem(void *chartInstanceVar)
{
  enable_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c1_flightControlSystem(void *chartInstanceVar)
{
  disable_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c1_flightControlSystem(void *chartInstanceVar)
{
  sf_gateway_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c1_flightControlSystem(SimStruct*
  S)
{
  return get_sim_state_c1_flightControlSystem
    ((SFc1_flightControlSystemInstanceStruct *)sf_get_chart_instance_ptr(S));/* raw sim ctx */
}

static void sf_opaque_set_sim_state_c1_flightControlSystem(SimStruct* S, const
  mxArray *st)
{
  set_sim_state_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    sf_get_chart_instance_ptr(S), st);
}

static void sf_opaque_cleanup_runtime_resources_c1_flightControlSystem(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc1_flightControlSystemInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_flightControlSystem_optimization_info();
    }

    mdl_cleanup_runtime_resources_c1_flightControlSystem
      ((SFc1_flightControlSystemInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_mdl_start_c1_flightControlSystem(void *chartInstanceVar)
{
  mdl_start_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
  if (chartInstanceVar) {
    sf_reset_warnings_ChartRunTimeInfo(((SFc1_flightControlSystemInstanceStruct*)
      chartInstanceVar)->S);
  }
}

static void sf_opaque_mdl_terminate_c1_flightControlSystem(void
  *chartInstanceVar)
{
  mdl_terminate_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c1_flightControlSystem(SimStruct *S)
{
  mdlProcessParamsCommon(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c1_flightControlSystem
      ((SFc1_flightControlSystemInstanceStruct*)sf_get_chart_instance_ptr(S));
  }
}

const char* sf_c1_flightControlSystem_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [21] = {
    "eNrdWM1uG1UUvk5CSlGpilRRFkjtCrFBpEmRWCBI6h9qKW4sxikVG3Q9c8Zz5Tt3JvfHjvsULHi",
    "FLirxIF2yg6eALlly7njsmLGJ545BCYw0mZyxv3vO/eY7P2NSa3cIHrfxfH6PkF28vo3nFpkeb+",
    "V2beGc3t8hX+R29x1C/IhK3RZhQtwPPwlgAMIzYcjOHbHCxF0qaawq+BU0hm9AJdxolgi34JkIQ",
    "YLwcYE0kdrJr2Kx4UwMW0b41rP6NmJ+5EWJ4cFjXJAGJ4JP/s5vanQXPTaYBF+3AAIdycQMohan",
    "g8tZkHpcj8AfKhM7c6VAeya1W1UdwzVLOTTPwW8LpSmyoNbs19NUQ12fOyuEKW+GTuKUMyrKcx1",
    "R5UGK6tBwmgb498RoZK+kX/TXZ4LqRDLKmzGvW4WXxHY5xtlBWXNnnnWsG9A3gwETA8uuNDEI3D",
    "/qpARXYT0ZgaQDOBGOOWh31zzPHvBcl+VzsG1lWSkHTTx9KqoSNvPbHCFDqqLfli/qlHPlhu0l6",
    "TGMgGf+G1TTCtipfwewUizoJc+otFngmElGsDMDObaeiICVf8KjAioruE+xeJaAs9hKCgKkeR76",
    "fKF1mjRKJ3Ed06hxfFzS3zK2LTTIkPpQuvZJyhRgwJmuHP0GTNE+t2hkSWe7LL0CiMpQokIjGuN",
    "EDpFj1yJ7wZXNBDc0BANogIasYDRR3c8oNyVjjhVWOCuPU4UVy80vYm3+VAL71I8gsP2EceiAsg",
    "uo0vUZ+8gR7nbE9KQBypcsLZtJRkGAjcSy1JukcCqGIhmLlkxiL58ILtEVAFYNKgW2hcfYluSkh",
    "cGXi1rCWc8qq8p4FlPNad9q42sQ2FnsXm0npD5mVVPg6IYBbYL12Ats7UIxpXGcmjSzHAiyefSD",
    "mts8+l5uH8xzqa16Ep8UxTYscFI66mfDHvRYDNkNj+JMMTXzw/rdIxd+b25d7ncL/6tVxJENcU8",
    "WcDsr+Hl/AXcnt/2H34ecDSJbhLVMuDdB3uPlOG6V4HtV/EUcWcJd8Dy7fryAr63wSxau6/jaXu",
    "Jrm9RqtQx3uIB7t+Bnp4DbzTl7efDRq99/aH36y0+vfzzZ/e3NJvr42VHPt3P7w9l8Nu9go6UiX",
    "0YP9wp6sLbqNLrh0+HeIzF5cQaeifbpc1l/kq33wDHe2f0HeGoscFm9lH47yN+1rE3N9B3Arv/5",
    "Qry7a9a/uaAnQt58tRn+7mERv4qvGwW+rN0ft2NsF3/R73WvF1dVn64yzjL1a7sirkb+vXr5T+I",
    "23Z9rXf6vf3/vknpACt+/c433UbxW7c/XbV+/Erd+dD+3v5y/O9cjxoMV03v+MQ7Y4apP/yf6/s",
    "ORv9m80LT85T/+fXdwJCif4Lg+fR3Kb3el/d1p/pEEqla/E11FH5pdD9f0+1uF/Lb2mIkgGatPH",
    "u5/tr9JX/sT0zMEIQ==",
    ""
  };

  static char newstr [1445] = "";
  newstr[0] = '\0';
  for (i = 0; i < 21; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c1_flightControlSystem(SimStruct *S)
{
  const char* newstr = sf_c1_flightControlSystem_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(2837853093U));
  ssSetChecksum1(S,(793153775U));
  ssSetChecksum2(S,(2496179415U));
  ssSetChecksum3(S,(4042131023U));
}

static void mdlRTW_c1_flightControlSystem(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlSetupRuntimeResources_c1_flightControlSystem(SimStruct *S)
{
  SFc1_flightControlSystemInstanceStruct *chartInstance;
  chartInstance = (SFc1_flightControlSystemInstanceStruct *)utMalloc(sizeof
    (SFc1_flightControlSystemInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc1_flightControlSystemInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c1_flightControlSystem;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c1_flightControlSystem;
  chartInstance->chartInfo.mdlStart = sf_opaque_mdl_start_c1_flightControlSystem;
  chartInstance->chartInfo.mdlTerminate =
    sf_opaque_mdl_terminate_c1_flightControlSystem;
  chartInstance->chartInfo.mdlCleanupRuntimeResources =
    sf_opaque_cleanup_runtime_resources_c1_flightControlSystem;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c1_flightControlSystem;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c1_flightControlSystem;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c1_flightControlSystem;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c1_flightControlSystem;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c1_flightControlSystem;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c1_flightControlSystem;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c1_flightControlSystem;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_setup_runtime_resources_c1_flightControlSystem(chartInstance);
}

void c1_flightControlSystem_method_dispatcher(SimStruct *S, int_T method, void
  *data)
{
  switch (method) {
   case SS_CALL_MDL_SETUP_RUNTIME_RESOURCES:
    mdlSetupRuntimeResources_c1_flightControlSystem(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c1_flightControlSystem(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c1_flightControlSystem(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c1_flightControlSystem_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
